using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIREST.DAO.Models
{
    public class PreguntaModel
    {
        public int id;
        public string pregunta;
        public int qntDistractors;

        public PreguntaModel(int id, string pregunta, int qntDistractors)
        {
            this.id = id;
            this.pregunta = pregunta;
            this.qntDistractors = qntDistractors;
        }
    }
}
