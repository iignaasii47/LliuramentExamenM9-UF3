using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIREST.DAO.Models
{
    public class RespostaModel
    {
        public int id;
        public string nomUsuari;
        public int idPregunta;
        public int numDistractor;
        public bool esCorrecte;

        public RespostaModel(int id, string nomUsuari, int idPregunta, int numDistractor, bool esCorrecte)
        {
            this.id = id;
            this.nomUsuari = nomUsuari;
            this.idPregunta = idPregunta;
            this.numDistractor = numDistractor;
            this.esCorrecte = esCorrecte;
        }
    }
}
