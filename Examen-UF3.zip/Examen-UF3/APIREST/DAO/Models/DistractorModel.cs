using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIREST.DAO.Models
{
    public class DistractorModel
    {
        public int idPregunta;
        public int numDistractor;
        public float valor;

        public DistractorModel(int idPregunta, int numDistractor, float valor)
        {
            this.idPregunta = idPregunta;
            this.numDistractor = numDistractor;
            this.valor = valor;
        }
    }
}
