﻿using System;
using System.Data.SqlClient;

namespace APIREST.DAO
{
    public static class Database
    {
        static String address = "Server=VODNOYSVET-PC\\SQLEXPRESS;Trusted_Connection=True;Database=Preguntes;Max Pool Size=400;Connect Timeout=600;";
        static SqlConnection objConn = null;
        

        public static SqlConnection GetConnection()
        {
            if(objConn == null) {
                objConn = new SqlConnection(address);
                objConn.Open();
                return objConn;
            }
            return objConn;
        }
    }
}
