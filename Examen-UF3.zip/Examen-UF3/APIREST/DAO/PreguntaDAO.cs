using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIREST.DAO;

using System.Data;
using System.Data.SqlClient;
using APIREST.DAO.Models;

namespace APIREST.DAO
{
    public static class PreguntaDAO
    {
        public static PreguntaModel read()
        {
            Random r = new Random();
            int id = r.Next(18)+1;
            System.Diagnostics.Debug.WriteLine(id);
            string queryString = "SELECT * FROM dbo.pregunta where id ="+ id +";";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            PreguntaModel p = null;
            try
            {
                while (reader.Read())
                {
                    p = new PreguntaModel(
                        Int32.Parse(reader[0].ToString()), 
                        reader[1].ToString(), 
                        Int32.Parse(reader[2].ToString()));
                }
            }
            finally
            {
                // Always call Close when done reading.
                reader.Close();
            }
            return p;
        }
    }
}
