using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIREST.DAO;

using System.Data;
using System.Data.SqlClient;
using APIREST.DAO.Models;

namespace APIREST.DAO
{
    public static class RespostaDAO
    {
        public static void insertResposta(int idPregunta, string usuari, string resposta)
        {
            bool esCorrecte = false;
            int distractor = 0;
            string queryString1 = "SELECT * FROM dbo.distractor where idPregunta ="+ idPregunta +";";
            SqlCommand cmd1 = new SqlCommand(queryString1, Database.GetConnection());
            SqlDataReader reader1 = cmd1.ExecuteReader();
            DistractorModel d = null;
            List<DistractorModel> list = new List<DistractorModel>();
            try
            {
                while (reader1.Read())
                {
                    d = new DistractorModel(
                        Int32.Parse(reader1[0].ToString()), 
                        Int32.Parse(reader1[1].ToString()),  
                        float.Parse(reader1[2].ToString()));

                    list.Add(d);
                }
            }
            finally
            {
                // Always call Close when done reading.
                reader1.Close();
            }

            for (int i=0; i<resposta.Length; ++i)
            {
                if (resposta[i] == '1')
                {
                    distractor = i+1;
                    if (list[i].valor > 0) 
                    {
                        esCorrecte = true;
                    }
                    else
                    {
                        esCorrecte = false;
                    }
                    break;
                }
            }
            System.Diagnostics.Debug.WriteLine("el valor de la cosa es "+ esCorrecte);
            string queryString = "INSERT INTO dbo.resposta (nomUsuari, idPregunta, numDistractor, esCorrecte) "+                              
                                "values ('"+usuari+"', '"+idPregunta+"', '"+distractor+"', '"+esCorrecte+"');";
            System.Diagnostics.Debug.WriteLine(queryString);
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Close();
        }

        public static int getNota(string usuari)
        {
            string queryString1 = "SELECT * FROM dbo.resposta where nomUsuari ="+ usuari +";";
            SqlCommand cmd1 = new SqlCommand(queryString1, Database.GetConnection());
            SqlDataReader reader1 = cmd1.ExecuteReader();
            RespostaModel r = null;
            List<RespostaModel> list = new List<RespostaModel>();
            try
            {
                while (reader1.Read())
                {
                    r = new RespostaModel(
                        Int32.Parse(reader1[0].ToString()), 
                        reader1[1].ToString(),  
                        Int32.Parse(reader1[2].ToString()),
                        Int32.Parse(reader1[3].ToString()),
                        bool.Parse(reader1[4].ToString()));

                    list.Add(r);
                }
            }
            finally
            {
                // Always call Close when done reading.
                reader1.Close();
            }

            float score = 0;
            foreach (var resposta in list)
            {
                string qs = "SELECT * FROM dbo.distractor where idPregunta ="+ resposta.idPregunta +" and numDistractor ="+ resposta.numDistractor +";";

                SqlCommand cmd2 = new SqlCommand(queryString1, Database.GetConnection());
                SqlDataReader reader2 = cmd1.ExecuteReader();

                bool isCorrecte;
                try
                {
                    while (reader1.Read())
                    {
                        // OUT OF TIME
                    }
                }
                finally
                {
                    // Always call Close when done reading.
                    reader1.Close();
                }

            }


            return 0;
        }
    }
}
