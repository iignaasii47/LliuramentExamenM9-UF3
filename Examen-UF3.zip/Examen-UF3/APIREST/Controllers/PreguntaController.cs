using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using APIREST.DAO;
using APIREST.DAO.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.IO;

namespace APIREST.Controllers
{
    [Route("api/")]
    [ApiController]
    public class PreguntaController : ControllerBase
    {
        [HttpGet("pregunta")]
        public Object Get()
        {
            return JsonConvert.SerializeObject(PreguntaDAO.read(), formatting: Formatting.Indented);
        }
    }
}
