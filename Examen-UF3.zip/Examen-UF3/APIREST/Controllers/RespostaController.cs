using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using APIREST.DAO;
using APIREST.DAO.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.IO;

namespace APIREST.Controllers
{
    [Route("api/")]
    [ApiController]
    public class RespostaController : ControllerBase
    {
        [HttpGet("resposta/{idPregunta}-{usuari}-{resposta}")]
        public void Get(int idPregunta, string usuari, string resposta)
        {
            RespostaDAO.insertResposta(idPregunta, usuari, resposta);
        }

        [HttpGet("nota/{usuari}")]
        public void Nota(string usuari)
        {
            RespostaDAO.getNota(usuari);
        }
    }
}
