USE [master]
GO

CREATE DATABASE [Preguntes]
GO
ALTER DATABASE [Preguntes] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Preguntes].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Preguntes] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Preguntes] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Preguntes] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Preguntes] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Preguntes] SET ARITHABORT OFF 
GO
ALTER DATABASE [Preguntes] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [Preguntes] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Preguntes] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Preguntes] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Preguntes] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Preguntes] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Preguntes] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Preguntes] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Preguntes] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Preguntes] SET  DISABLE_BROKER 
GO
ALTER DATABASE [Preguntes] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Preguntes] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Preguntes] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Preguntes] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Preguntes] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Preguntes] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Preguntes] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Preguntes] SET RECOVERY FULL 
GO
ALTER DATABASE [Preguntes] SET  MULTI_USER 
GO
ALTER DATABASE [Preguntes] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Preguntes] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Preguntes] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Preguntes] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Preguntes] SET DELAYED_DURABILITY = DISABLED 
GO
EXEC sys.sp_db_vardecimal_storage_format N'Preguntes', N'ON'
GO
ALTER DATABASE [Preguntes] SET QUERY_STORE = OFF
GO
USE [Preguntes]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE function [dbo].[avalua](@usuari nvarchar(50))
 returns decimal(11,9)
as
begin
  declare @val decimal(11,9);
  declare @qnt int;
  
  /* si hi ha menys de 3 respostes de l usuari --> null */
  /* select @qnt=count(distinct idPregunta) from resposta where nomUsuari=@usuari;
   if (@qnt<3) return null; */

  /* nom�s cal considerar els distractors que l usuari considera correctes */
  select @val=sum(d.valor)
   from resposta r
    inner join distractor d on d.idPregunta=r.idPregunta and d.numDistractor=r.numDistractor
	where nomUsuari=@usuari and r.esCorrecte=1;

  if (@qnt>0) 
  begin
     set @val= @val*10/@qnt;
	 if (@val<0) 
	    set @val=0;
  end
  else
     set @val= null;
  
  return @val;
end;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[distractor](
	[idPregunta] [int] NOT NULL,
	[numDistractor] [int] NOT NULL,
	[valor] [decimal](10, 9) NOT NULL,
 CONSTRAINT [PK_distractor_1] PRIMARY KEY CLUSTERED 
(
	[idPregunta] ASC,
	[numDistractor] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[pregunta](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[pregunta] [nvarchar](500) NULL,
	[qntDistractors] [int] NULL,
 CONSTRAINT [PK_pregunta] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[resposta](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[nomUsuari] [nvarchar](50) NULL,
	[idPregunta] [int] NULL,
	[numDistractor] [int] NULL,
	[esCorrecte] [bit] NULL,
 CONSTRAINT [PK_resposta] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (1, 1, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (1, 2, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (1, 3, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (1, 4, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (2, 1, CAST(0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (2, 2, CAST(0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (2, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (2, 4, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (3, 1, CAST(0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (3, 2, CAST(0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (3, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (3, 4, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (4, 1, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (4, 2, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (4, 3, CAST(0.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (4, 4, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (5, 1, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (5, 2, CAST(-1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (6, 1, CAST(-1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (6, 2, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (7, 1, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (7, 2, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (7, 3, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (7, 4, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (8, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (8, 2, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (8, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (9, 1, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (9, 2, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (9, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (10, 1, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (10, 2, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (10, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (11, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (11, 2, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (11, 3, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (12, 1, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (12, 2, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (12, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (13, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (13, 2, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (13, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (14, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (14, 2, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (14, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (15, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (15, 2, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (15, 3, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (16, 1, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (16, 2, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (16, 3, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (16, 4, CAST(-0.333333333 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (17, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (17, 2, CAST(1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (17, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (18, 1, CAST(-0.500000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (18, 2, CAST(-1.000000000 AS Decimal(10, 9)))
GO
INSERT [dbo].[distractor] ([idPregunta], [numDistractor], [valor]) VALUES (18, 3, CAST(-0.500000000 AS Decimal(10, 9)))
GO
SET IDENTITY_INSERT [dbo].[pregunta] ON 
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (1, N'Quantes PKs hauria tenir tota taula d�una base de dades relacional?
a) n
b) 0
c) 1
d) 1 o m�s', 4)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (2, N'Quantes FKs pot tenir una taula d�una base de dades relacional?
a) com a m�xim la quantitat d�atributs
b) com a m�nim 0
c) com a m�nim 1
d) com a m�xim 2', 4)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (3, N'Quants atributs pot tenir una taula d�una base de dades relacional en la PK?
a) com a m�xim la quantitat d�atributs
b) Habitualment, 1
c) Habitualment, 2
d) mai tots els atributs', 4)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (4, N'De qu� color es el caballo blanco de Santiago?
a) blanc
b) negre
c) no ho s�
d) pardo, com l�euga de casa', 4)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (5, N'Disposar d�un �ndex en un atribut molt usat per a fer cerques pot tenir un impacte positiu en el rendiment?
a) CERT
b) FALS', 2)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (6, N'Una clau candidata pot tenir subconjunts que siguin claus candidates?
a) CERT
b) FALS', 2)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (7, N'Si tinc 4 claus candidates, quantes claus alternatives puc tenir?
a) 1
b) 2
c) 3
d) 4', 4)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (8, N'Puc tractar una especialitzaci� solapada com si fos una relaci� exclusiva?
a) s�
b) no
c) de vegades', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (9, N'Una taula que compleix 1FN i no t� atributs fora de la clau, est� en 2FN? 
a) s�
b) no
c) de vegades', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (10, N'Una taula que compleix 1FN i no t� atributs fora de la clau, est� en 3FN? 
a) s�
b) no
c) de vegades', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (11, N'Una taula que compleix 1FN i t� dos atributs a la clau i un fora, est� en 2FN?
a) s�
b) no
c) de vegades', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (12, N'Una taula que compleix 2FN i t� dos atributs a la clau i un fora, est� en 3FN?
a) s�
b) no
c) de vegades', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (13, N'Quan convertim un diagrama entitat-relaci� a model relacional, on posarem les propietats d una relaci� 1:N?
a) a la part 1
b) a la part N
c) tant se val', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (14, N'Un left join amb nulls a la taula de la dreta �s com una subconsulta del tipus...
a) in
b) not in
c) de taula', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (15, N'Quin operador de SQL �s ternari?
a) IN
b) LIKE
c) BETWEEN', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (16, N'En SQL, quin significat t� el % en una instrucci� LIKE?
a) De 1 a n
b) 0 o 1
c) De 0 a n
d) Exactament 1', 4)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (17, N'Quin operador t� m�s prioritat?
a) AND
b) NOT
c) OR', 3)
GO
INSERT [dbo].[pregunta] ([id], [pregunta], [qntDistractors]) VALUES (18, N'Com podem crear una nova taula en una base de dades relacional?
a) CREATE TABLE
b) INSERT... SELECT
c) SELECT... INTO', 3)
GO
SET IDENTITY_INSERT [dbo].[pregunta] OFF
GO
ALTER TABLE [dbo].[distractor]  WITH CHECK ADD  CONSTRAINT [FK_distractor_pregunta] FOREIGN KEY([idPregunta])
REFERENCES [dbo].[pregunta] ([id])
GO
ALTER TABLE [dbo].[distractor] CHECK CONSTRAINT [FK_distractor_pregunta]
GO
ALTER TABLE [dbo].[resposta]  WITH CHECK ADD  CONSTRAINT [FK_resposta_distractor] FOREIGN KEY([idPregunta], [numDistractor])
REFERENCES [dbo].[distractor] ([idPregunta], [numDistractor])
GO
ALTER TABLE [dbo].[resposta] CHECK CONSTRAINT [FK_resposta_distractor]
GO
USE [master]
GO
ALTER DATABASE [Preguntes] SET  READ_WRITE 
GO